package com.subscription.service;

import com.subscription.model.Payment;
import com.subscription.model.Subscription;
import com.subscription.repository.PaymentRepository;
import com.subscription.repository.SubscriptionRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class PaymentService {

    private final PaymentRepository payments;
    private final SubscriptionRepository subscriptions;

    public PaymentService(PaymentRepository payments, SubscriptionRepository subscriptions) {
        this.payments = payments;
        this.subscriptions = subscriptions;
    }

    public List<Payment> listBySubscription(Long subscriptionId) {
        requireSubscription(subscriptionId);
        return payments.findBySubscriptionId(subscriptionId);
    }


    public Payment create(Long subscriptionId, Payment p) {
        Subscription sub = requireSubscription(subscriptionId);
        validateCreate(p);
        p.setSubscription(sub);
        return payments.save(p);
    }

    public Payment get(Long id) {
        return payments.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Payment not found: " + id));
    }

    public Payment update(Long id, Payment patch) {
        Payment existing = get(id);

        if (patch.getAmount() != null) {
            if (isNegative(patch.getAmount())) {
                throw new IllegalArgumentException("Amount must be >= 0");
            }
            existing.setAmount(patch.getAmount());
        }
        if (patch.getPaidDate() != null) {
            existing.setPaidDate(patch.getPaidDate());
        }
        if (patch.getMethod() != null) {
            existing.setMethod(patch.getMethod());
        }
        if (patch.getNotes() != null) {
            existing.setNotes(patch.getNotes());
        }

        return payments.save(existing);
    }

    public void delete(Long id) {
        if (!payments.existsById(id)) {
            throw new NoSuchElementException("Payment not found: " + id);
        }
        payments.deleteById(id);
    }

  

    private Subscription requireSubscription(Long subscriptionId) {
        return subscriptions.findById(subscriptionId)
                .orElseThrow(() -> new NoSuchElementException("Subscription not found: " + subscriptionId));
    }

    private void validateCreate(Payment p) {
        if (p.getAmount() == null || isNegative(p.getAmount())) {
            throw new IllegalArgumentException("Amount must be >= 0");
        }
        if (p.getPaidDate() == null) {
            throw new IllegalArgumentException("paidDate is required (YYYY-MM-DD)");
        }
    }

    private boolean isNegative(BigDecimal value) {
        return value.compareTo(BigDecimal.ZERO) < 0;
    }
}