package com.subscription.service;

import com.subscription.model.User;
import com.subscription.repository.UserRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class UserService {

    private final UserRepository users;

    public UserService(UserRepository users) {
        this.users = users;
    }

    public List<User> getAll() {
        return users.findAll();
    }

    public User create(User u) {
        if (u.getName() == null || u.getName().isBlank()) {
            throw new IllegalArgumentException("Name is required");
        }
        if (u.getEmail() == null || u.getEmail().isBlank()) {
            throw new IllegalArgumentException("Email is required");
        }
        if (users.existsByEmail(u.getEmail())) {
            throw new DataIntegrityViolationException("Email already exists");
        }
        return users.save(u);
    }

    public User get(Long id) {
        return users.findById(id).orElseThrow(() -> new NoSuchElementException("User not found: " + id));
    }

    public User update(Long id, User patch) {
        User existing = get(id);

        if (patch.getName() != null && !patch.getName().isBlank()) {
            existing.setName(patch.getName());
        }
        if (patch.getEmail() != null && !patch.getEmail().isBlank()) {
            if (!patch.getEmail().equals(existing.getEmail()) && users.existsByEmail(patch.getEmail())) {
                throw new DataIntegrityViolationException("Email already exists");
            }
            existing.setEmail(patch.getEmail());
        }
        return users.save(existing);
    }

    public void delete(Long id) {
        if (!users.existsById(id)) {
            throw new NoSuchElementException("User not found: " + id);
        }
        users.deleteById(id);
    }
}