package com.subscription.service;

import com.subscription.model.BillingCycle;
import com.subscription.model.Subscription;
import com.subscription.model.SubscriptionStatus;
import com.subscription.model.User;
import com.subscription.repository.SubscriptionRepository;
import com.subscription.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class SubscriptionService {

    private final SubscriptionRepository subscriptions;
    private final UserRepository users;

    public SubscriptionService(SubscriptionRepository subscriptions, UserRepository users) {
        this.subscriptions = subscriptions;
        this.users = users;
    }

    public List<Subscription> listByUser(Long userId) {
        if (!users.existsById(userId)) {
            throw new NoSuchElementException("User not found: " + userId);
        }
        return subscriptions.findByUserId(userId);
    }

  
    public Subscription create(Long userId, Subscription s) {
        User user = users.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found: " + userId));

        validateCreate(s);

        s.setUser(user);

        if (s.getStatus() == null) {
            s.setStatus(SubscriptionStatus.ACTIVE);
        }
        if (s.getStartDate() == null) {
            s.setStartDate(LocalDate.now());
        }
        if (s.getNextRenewalDate() == null) {
            s.setNextRenewalDate(computeNextRenewalFuture(s.getStartDate(), s.getBillingCycle()));
        }

        return subscriptions.save(s);
    }

    public Subscription get(Long id) {
        return subscriptions.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Subscription not found: " + id));
    }

    public Subscription update(Long id, Subscription patch) {
        Subscription existing = get(id);

        if (patch.getName() != null && !patch.getName().isBlank()) {
            existing.setName(patch.getName());
        }
        if (patch.getAmount() != null) {
            if (isNegative(patch.getAmount())) {
                throw new IllegalArgumentException("Amount must be >= 0");
            }
            existing.setAmount(patch.getAmount());
        }

        boolean startChanged = false;
        boolean cycleChanged = false;

        if (patch.getStartDate() != null) {
            existing.setStartDate(patch.getStartDate());
            startChanged = true;
        }
        if (patch.getBillingCycle() != null) {
            existing.setBillingCycle(patch.getBillingCycle());
            cycleChanged = true;
        }
        if (patch.getStatus() != null) {
            existing.setStatus(patch.getStatus());
        }

        if (patch.getNextRenewalDate() != null) {
            existing.setNextRenewalDate(patch.getNextRenewalDate());
        } else if (startChanged || cycleChanged) {
            LocalDate effectiveStart = existing.getStartDate() != null ? existing.getStartDate() : LocalDate.now();
            BillingCycle effectiveCycle = existing.getBillingCycle();
            if (effectiveCycle == null) {
                throw new IllegalArgumentException("Billing cycle required to compute renewal");
            }
            existing.setNextRenewalDate(computeNextRenewalFuture(effectiveStart, effectiveCycle));
        }

        return subscriptions.save(existing);
    }
    public void delete(Long id) {
        if (!subscriptions.existsById(id)) {
            throw new NoSuchElementException("Subscription not found: " + id);
        }
        subscriptions.deleteById(id);
    }


    private void validateCreate(Subscription s) {
        if (s.getName() == null || s.getName().isBlank()) {
            throw new IllegalArgumentException("Subscription name is required");
        }
        if (s.getAmount() == null || isNegative(s.getAmount())) {
            throw new IllegalArgumentException("Amount must be >= 0");
        }
        if (s.getBillingCycle() == null) {
            throw new IllegalArgumentException("Billing cycle is required (MONTHLY/YEARLY)");
        }
    }

    private boolean isNegative(BigDecimal value) {
        return value.compareTo(BigDecimal.ZERO) < 0;
    }

    private LocalDate computeNextRenewalFuture(LocalDate base, BillingCycle cycle) {
        LocalDate next = addOneCycle(base, cycle);
        LocalDate today = LocalDate.now();
        while (!next.isAfter(today)) {
            next = addOneCycle(next, cycle);
        }
        return next;
    }

    private LocalDate addOneCycle(LocalDate date, BillingCycle cycle) {
        return (cycle == BillingCycle.MONTHLY) ? date.plusMonths(1) : date.plusYears(1);
    }
}