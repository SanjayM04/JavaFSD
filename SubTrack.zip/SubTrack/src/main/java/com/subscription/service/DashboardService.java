package com.subscription.service;

import com.subscription.model.BillingCycle;
import com.subscription.model.Subscription;
import com.subscription.model.SubscriptionStatus;
import com.subscription.repository.SubscriptionRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class DashboardService {

    private final SubscriptionRepository subscriptions;

    public DashboardService(SubscriptionRepository subscriptions) {
        this.subscriptions = subscriptions;
    }

    
    public DashboardSummary getSummary(int daysAhead, Long userId) {
        LocalDate today = LocalDate.now();

        List<Subscription> activeSubs = (userId == null)
                ? subscriptions.findByStatus(SubscriptionStatus.ACTIVE)
                : subscriptions.findByUserIdAndStatus(userId, SubscriptionStatus.ACTIVE);

        BigDecimal monthlyTotal = activeSubs.stream()
                .map(s -> monthlyEquivalent(s.getAmount(), s.getBillingCycle()))
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_UP);

        BigDecimal yearlyTotal = monthlyTotal
                .multiply(BigDecimal.valueOf(12))
                .setScale(2, RoundingMode.HALF_UP);

        LocalDate cutoff = today.plusDays(daysAhead);

        List<Subscription> withDates = activeSubs.stream()
                .filter(s -> s.getNextRenewalDate() != null)
                .toList();

        List<Subscription> overdue = withDates.stream()
                .filter(s -> s.getNextRenewalDate().isBefore(today))
                .sorted(Comparator.comparing(Subscription::getNextRenewalDate))
                .toList();

        List<Subscription> dueSoonWindow = withDates.stream()
                .filter(s -> !s.getNextRenewalDate().isBefore(today) && !s.getNextRenewalDate().isAfter(cutoff))
                .sorted(Comparator.comparing(Subscription::getNextRenewalDate))
                .toList();

        List<Map<String,Object>> upcomingRenewals = dueSoonWindow.stream()
                .map(s -> Map.<String,Object>of(
                        "subscriptionId", s.getId(),
                        "name", s.getName(),
                        "nextRenewalDate", s.getNextRenewalDate(),
                        "daysLeft", daysBetween(today, s.getNextRenewalDate()),
                        "amount", s.getAmount(),
                        "billingCycle", s.getBillingCycle()
                ))
                .toList();

        
        long dueSoon7 = withDates.stream()
                .filter(s -> {
                    LocalDate d = s.getNextRenewalDate();
                    return !d.isBefore(today) && !d.isAfter(today.plusDays(7));
                })
                .count();

        long dueSoon30 = withDates.stream()
                .filter(s -> {
                    LocalDate d = s.getNextRenewalDate();
                    return !d.isBefore(today) && !d.isAfter(today.plusDays(30));
                })
                .count();

        List<Map<String,Object>> overdueRenewals = overdue.stream()
                .map(s -> Map.<String,Object>of(
                        "subscriptionId", s.getId(),
                        "name", s.getName(),
                        "nextRenewalDate", s.getNextRenewalDate(),
                        "daysOverdue", daysBetween(s.getNextRenewalDate(), today),
                        "amount", s.getAmount(),
                        "billingCycle", s.getBillingCycle()
                ))
                .toList();

        return new DashboardSummary(
                monthlyTotal,
                yearlyTotal,
                activeSubs.size(),
                upcomingRenewals,
                overdueRenewals,
                dueSoon7,
                dueSoon30
        );
    }

    private BigDecimal monthlyEquivalent(BigDecimal amount, BillingCycle cycle) {
        if (amount == null) return BigDecimal.ZERO;
        return (cycle == BillingCycle.YEARLY)
                ? amount.divide(BigDecimal.valueOf(12), 6, RoundingMode.HALF_UP)
                : amount;
    }

    private long daysBetween(LocalDate start, LocalDate end) {
        return end.toEpochDay() - start.toEpochDay();
    }

    public record DashboardSummary(
            BigDecimal monthlyTotal,
            BigDecimal yearlyTotal,
            int activeSubscriptions,
            List<Map<String, Object>> upcomingRenewals,
            List<Map<String, Object>> overdueRenewals,
            long dueSoon7,
            long dueSoon30
    ) {}
}