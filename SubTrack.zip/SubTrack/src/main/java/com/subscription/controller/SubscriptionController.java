package com.subscription.controller;

import com.subscription.model.Subscription;
import com.subscription.service.SubscriptionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class SubscriptionController {

    private final SubscriptionService service;

    public SubscriptionController(SubscriptionService service) {
        this.service = service;
    }

    
    @PostMapping("/users/{userId}/subscriptions")
    public ResponseEntity<Subscription> create(
            @PathVariable Long userId,
            @Valid @RequestBody Subscription payload
    ) {
        Subscription created = service.create(userId, payload);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

   
    @GetMapping("/users/{userId}/subscriptions")
    public List<Subscription> listByUser(@PathVariable Long userId) {
        return service.listByUser(userId);
    }

    
    @GetMapping("/subscriptions/{id}")
    public Subscription get(@PathVariable Long id) {
        return service.get(id);
    }

    
    @PutMapping("/subscriptions/{id}")
    public Subscription update(
            @PathVariable Long id,
            @Valid @RequestBody Subscription patch
    ) {
        return service.update(id, patch);
    }

    
    @DeleteMapping("/subscriptions/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}