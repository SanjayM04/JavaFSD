package com.subscription.controller;

import com.subscription.model.User;
import com.subscription.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@CrossOrigin
public class UserController {

    private final UserService service;

    public UserController(UserService service) { this.service = service; }

    @GetMapping
    public List<User> all() { return service.getAll(); }

    @PostMapping
    public ResponseEntity<User> create(@Valid @RequestBody User u) {
        User created = service.create(u);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping("/{id}")
    public User get(@PathVariable Long id) { return service.get(id); }

    @PutMapping("/{id}")
    public User update(@PathVariable Long id, @Valid @RequestBody User patch) {
        return service.update(id, patch);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}