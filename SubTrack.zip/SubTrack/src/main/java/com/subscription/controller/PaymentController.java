package com.subscription.controller;

import com.subscription.model.Payment;
import com.subscription.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class PaymentController {

    private final PaymentService service;

    public PaymentController(PaymentService service) {
        this.service = service;
    }

    
    @PostMapping("/subscriptions/{subscriptionId}/payments")
    public ResponseEntity<Payment> create(
            @PathVariable Long subscriptionId,
            @Valid @RequestBody Payment payload
    ) {
        Payment created = service.create(subscriptionId, payload);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    
    @GetMapping("/subscriptions/{subscriptionId}/payments")
    public List<Payment> list(@PathVariable Long subscriptionId) {
        return service.listBySubscription(subscriptionId);
    }

   
    @GetMapping("/payments/{id}")
    public Payment get(@PathVariable Long id) {
        return service.get(id);
    }

    @PutMapping("/payments/{id}")
    public Payment update(
            @PathVariable Long id,
            @Valid @RequestBody Payment patch
    ) {
        return service.update(id, patch);
    }

    
    @DeleteMapping("/payments/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}