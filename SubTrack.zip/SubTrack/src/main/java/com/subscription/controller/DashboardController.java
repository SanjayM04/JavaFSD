package com.subscription.controller;

import com.subscription.service.DashboardService;
import com.subscription.service.DashboardService.DashboardSummary;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin
public class DashboardController {

    private final DashboardService service;

    public DashboardController(DashboardService service) {
        this.service = service;
    }

    
    @GetMapping("/summary")
    public ResponseEntity<DashboardSummary> summary(
            @RequestParam(name = "days", defaultValue = "30") int days,
            @RequestParam(name = "userId", required = false) Long userId
    ) {
        if (days < 0) days = 0;
        return ResponseEntity.ok(service.getSummary(days, userId));
    }
}