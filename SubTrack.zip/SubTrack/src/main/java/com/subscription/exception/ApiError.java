package com.subscription.exception;

import jakarta.servlet.http.HttpServletRequest;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class ApiError {
    private String timestamp;
    private int status;
    private String error;
    private String message;
    private String path;
    private List<FieldViolation> errors = new ArrayList<>();

    public ApiError(int status, String error, String message, String path) {
        this.timestamp = Instant.now().toString();
        this.status = status;
        this.error = error;
        this.message = message;
        this.path = path;
    }

    public static ApiError of(int status, String error, String message, HttpServletRequest req) {
        return new ApiError(status, error, message, req != null ? req.getRequestURI() : null);
    }

    public void addViolation(String field, String message) {
        errors.add(new FieldViolation(field, message));
    }

    public String getTimestamp() { return timestamp; }
    public int getStatus() { return status; }
    public String getError() { return error; }
    public String getMessage() { return message; }
    public String getPath() { return path; }
    public List<FieldViolation> getErrors() { return errors; }

    public static class FieldViolation {
        private String field;
        private String message;
        public FieldViolation(String field, String message) {
            this.field = field; this.message = message;
        }
        public String getField() { return field; }
        public String getMessage() { return message; }
    }
}