package com.subscription.model;

public enum BillingCycle {
	MONTHLY,
	YEARLY
}
