package com.subscription.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "subscriptions")
public class Subscription {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false, foreignKey = @ForeignKey(name = "fk_subscription_user"))
    private User user;

    @NotBlank(message = "Subscription name is required")
    @Column(nullable = false)
    private String name;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.00", message = "Amount must be ≥ 0")
    @Digits(integer = 10, fraction = 2, message = "Amount must have up to 10 digits and 2 decimals")
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;

    @NotNull(message = "Billing cycle is required")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private BillingCycle billingCycle;

    private LocalDate startDate;

    private LocalDate nextRenewalDate;

    @NotNull(message = "Status is required")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SubscriptionStatus status = SubscriptionStatus.ACTIVE;

    @JsonIgnore
    @OneToMany(mappedBy = "subscription", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Payment> payments = new ArrayList<>();

    public Long getId(){ return id; }
    public void setId(Long id){ this.id = id; }
    public User getUser(){ return user; }
    public void setUser(User user){ this.user = user; }
    public String getName(){ return name; }
    public void setName(String name){ this.name = name; }
    public BigDecimal getAmount(){ return amount; }
    public void setAmount(BigDecimal amount){ this.amount = amount; }
    public BillingCycle getBillingCycle(){ return billingCycle; }
    public void setBillingCycle(BillingCycle billingCycle){ this.billingCycle = billingCycle; }
    public LocalDate getStartDate(){ return startDate; }
    public void setStartDate(LocalDate startDate){ this.startDate = startDate; }
    public LocalDate getNextRenewalDate(){ return nextRenewalDate; }
    public void setNextRenewalDate(LocalDate nextRenewalDate){ this.nextRenewalDate = nextRenewalDate; }
    public SubscriptionStatus getStatus(){ return status; }
    public void setStatus(SubscriptionStatus status){ this.status = status; }
    public List<Payment> getPayments(){ return payments; }
    public void setPayments(List<Payment> payments){ this.payments = payments; }
}