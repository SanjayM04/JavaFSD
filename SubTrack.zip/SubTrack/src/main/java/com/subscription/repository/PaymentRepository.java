package com.subscription.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.subscription.model.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Long>{
	List<Payment> findBySubscriptionId(Long subscriptionId);
	List<Payment> findByPaidDateBetween(LocalDate start, LocalDate end);
}
