package com.subscription.repository;

import com.subscription.model.Subscription;
import com.subscription.model.SubscriptionStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {
    List<Subscription> findByUserId(Long userId);
    long countByStatus(SubscriptionStatus status);

    List<Subscription> findByStatus(SubscriptionStatus status);
    List<Subscription> findByUserIdAndStatus(Long userId, SubscriptionStatus status);
}