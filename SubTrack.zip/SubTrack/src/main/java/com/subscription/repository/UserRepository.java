package com.subscription.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.subscription.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
	boolean existsByEmail(String email);
}
