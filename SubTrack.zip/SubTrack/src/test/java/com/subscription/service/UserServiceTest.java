package com.subscription.service;

import com.subscription.model.User;
import com.subscription.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;

import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.springframework.dao.DataIntegrityViolationException;

class UserServiceTest {

    private UserRepository userRepository;
    private UserService service;

    @BeforeEach
    void setUp() {
        userRepository = mock(UserRepository.class);
        service = new UserService(userRepository);
    }

    @Test
    void create_ShouldSave_WhenValid() {
        User in = new User("Sanjay", "sanjay@example.com");
        when(userRepository.existsByEmail("sanjay@example.com")).thenReturn(false);
        when(userRepository.save(ArgumentMatchers.any(User.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        User out = service.create(in);

        assertEquals("Sanjay", out.getName());
        assertEquals("sanjay@example.com", out.getEmail());
        verify(userRepository).save(in);
    }

    @Test
    void create_ShouldFail_WhenEmailMissing() {
        User in = new User("Sanjay", null);
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> service.create(in));
        assertTrue(ex.getMessage().toLowerCase().contains("email"));
    }

    @Test
    void create_ShouldFail_WhenDuplicateEmail() {
        User in = new User("Sanjay", "dup@example.com");
        when(userRepository.existsByEmail("dup@example.com")).thenReturn(true);

        assertThrows(DataIntegrityViolationException.class, () -> service.create(in));
    }

    @Test
    void get_ShouldReturn_WhenExists() {
        User u = new User("Sanjay", "sanjay@example.com");
        u.setId(1L);
        when(userRepository.findById(1L)).thenReturn(Optional.of(u));

        User out = service.get(1L);
        assertEquals(1L, out.getId());
    }

    @Test
    void get_ShouldThrow_WhenMissing() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(NoSuchElementException.class, () -> service.get(99L));
    }

    @Test
    void update_ShouldMerge_AndSave() {
        User existing = new User("Old", "old@example.com");
        existing.setId(10L);
        when(userRepository.findById(10L)).thenReturn(Optional.of(existing));
        when(userRepository.existsByEmail("new@example.com")).thenReturn(false);
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));

        User patch = new User("New", "new@example.com");
        User out = service.update(10L, patch);

        assertEquals("New", out.getName());
        assertEquals("new@example.com", out.getEmail());
    }
}