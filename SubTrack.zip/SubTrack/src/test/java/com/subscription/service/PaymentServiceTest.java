package com.subscription.service;

import com.subscription.model.Payment;
import com.subscription.model.Subscription;
import com.subscription.repository.PaymentRepository;
import com.subscription.repository.SubscriptionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PaymentServiceTest {

    private PaymentRepository payRepo;
    private SubscriptionRepository subRepo;
    private PaymentService service;

    @BeforeEach
    void setUp() {
        payRepo = mock(PaymentRepository.class);
        subRepo = mock(SubscriptionRepository.class);
        service = new PaymentService(payRepo, subRepo);
    }

    @Test
    void create_ShouldSave_WhenValid() {
        Subscription sub = new Subscription();
        sub.setId(7L);
        when(subRepo.findById(7L)).thenReturn(Optional.of(sub));
        when(payRepo.save(any(Payment.class))).thenAnswer(inv -> inv.getArgument(0));

        Payment p = new Payment();
        p.setAmount(new BigDecimal("499.00"));
        p.setPaidDate(LocalDate.now());

        Payment out = service.create(7L, p);

        assertEquals(new BigDecimal("499.00"), out.getAmount());
        assertNotNull(out.getPaidDate());
    }

    @Test
    void create_ShouldFail_WhenSubscriptionMissing() {
        when(subRepo.findById(77L)).thenReturn(Optional.empty());

        Payment p = new Payment();
        p.setAmount(BigDecimal.ONE);
        p.setPaidDate(LocalDate.now());

        assertThrows(NoSuchElementException.class, () -> service.create(77L, p));
    }

    @Test
    void create_ShouldFail_WhenNegativeAmount() {
        Subscription sub = new Subscription(); sub.setId(9L);
        when(subRepo.findById(9L)).thenReturn(Optional.of(sub));

        Payment p = new Payment();
        p.setAmount(new BigDecimal("-1.00"));
        p.setPaidDate(LocalDate.now());

        assertThrows(IllegalArgumentException.class, () -> service.create(9L, p));
    }
}