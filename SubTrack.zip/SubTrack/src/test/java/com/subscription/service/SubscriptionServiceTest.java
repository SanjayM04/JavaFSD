package com.subscription.service;

import com.subscription.model.*;
import com.subscription.repository.SubscriptionRepository;
import com.subscription.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SubscriptionServiceTest {

    private SubscriptionRepository subRepo;
    private UserRepository userRepo;
    private SubscriptionService service;

    @BeforeEach
    void setUp() {
        subRepo = mock(SubscriptionRepository.class);
        userRepo = mock(UserRepository.class);
        service = new SubscriptionService(subRepo, userRepo);
    }

    @Test
    void create_ShouldSetDefaults_AndComputeNextRenewal() {
        User owner = new User("Sanjay", "sanjay@example.com"); owner.setId(1L);
        when(userRepo.findById(1L)).thenReturn(Optional.of(owner));
        when(subRepo.save(any(Subscription.class))).thenAnswer(inv -> inv.getArgument(0));

        Subscription s = new Subscription();
        s.setName("Netflix");
        s.setAmount(new BigDecimal("499.00"));
        s.setBillingCycle(BillingCycle.MONTHLY);
        s.setStatus(SubscriptionStatus.ACTIVE);
        
        Subscription out = service.create(1L, s);

        assertNotNull(out.getStartDate());
        assertNotNull(out.getNextRenewalDate());
        assertTrue(out.getNextRenewalDate().isAfter(LocalDate.now()));
    }

    @Test
    void create_ShouldFail_WhenUserMissing() {
        when(userRepo.findById(99L)).thenReturn(Optional.empty());

        Subscription s = new Subscription();
        s.setName("Plan");
        s.setAmount(BigDecimal.ONE);
        s.setBillingCycle(BillingCycle.YEARLY);
        s.setStatus(SubscriptionStatus.ACTIVE);

        assertThrows(NoSuchElementException.class, () -> service.create(99L, s));
    }

    @Test
    void update_ShouldRecomputeRenewal_WhenCycleOrStartChanges() {
        Subscription existing = new Subscription();
        existing.setId(10L);
        existing.setName("Tool");
        existing.setAmount(new BigDecimal("1200.00"));
        existing.setBillingCycle(BillingCycle.YEARLY);
        existing.setStartDate(LocalDate.now().minusYears(1));
        existing.setStatus(SubscriptionStatus.ACTIVE);

        when(subRepo.findById(10L)).thenReturn(Optional.of(existing));
        when(subRepo.save(any(Subscription.class))).thenAnswer(inv -> inv.getArgument(0));

        Subscription patch = new Subscription();
        patch.setBillingCycle(BillingCycle.MONTHLY); 
        Subscription out = service.update(10L, patch);

        assertEquals(BillingCycle.MONTHLY, out.getBillingCycle());
        assertNotNull(out.getNextRenewalDate());
        assertTrue(out.getNextRenewalDate().isAfter(LocalDate.now()));
    }
}