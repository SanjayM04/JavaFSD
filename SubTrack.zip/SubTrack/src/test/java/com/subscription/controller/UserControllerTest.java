package com.subscription.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.subscription.exception.GlobalExceptionHandler;
import com.subscription.model.User;
import com.subscription.service.UserService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UserController.class)
@Import(GlobalExceptionHandler.class) 
class UserControllerTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper om;

    @MockBean
    private UserService userService;

    @Test
    void create_ShouldReturn201_WhenValid() throws Exception {
        User in = new User("Sanjay", "sanjay@example.com");
        User out = new User("Sanjay", "sanjay@example.com");
        out.setId(1L);

        Mockito.when(userService.create(any(User.class))).thenReturn(out);

        mvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(om.writeValueAsString(in)))
           .andExpect(status().isCreated())
           .andExpect(jsonPath("$.id").value(1L))
           .andExpect(jsonPath("$.name").value("Sanjay"))
           .andExpect(jsonPath("$.email").value("sanjay@example.com"));
    }

    @Test
    void create_ShouldReturn400_WhenInvalid() throws Exception {
        User invalid = new User("", "");

        mvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(om.writeValueAsString(invalid)))
           .andExpect(status().isBadRequest())
           .andExpect(jsonPath("$.status").value(400))
           .andExpect(jsonPath("$.error").value("Bad Request"))
           .andExpect(jsonPath("$.errors").isArray())
           .andExpect(jsonPath("$.errors[?(@.field=='name')]").exists())
           .andExpect(jsonPath("$.errors[?(@.field=='email')]").exists());
    }
}