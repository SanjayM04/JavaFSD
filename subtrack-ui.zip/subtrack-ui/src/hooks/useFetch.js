import { useEffect, useState } from "react";

export default function useFetch(fetchFn, deps = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let alive = true; 
    setLoading(true);
    setError(null);

    fetchFn()
      .then((res) => {
        if (!alive) return;
        setData(res?.data ?? res);
      })
      .catch((err) => {
        if (!alive) return;
        const message =
          err?.response?.data?.error ||
          err?.message ||
          "Unexpected error occurred.";
        setError(message);
      })
      .finally(() => {
        if (!alive) return;
        setLoading(false);
      });

    return () => {
      alive = false; 
    };
  }, deps);

  return { data, loading, error, setData };
}