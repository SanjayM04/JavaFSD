import { configureStore } from "@reduxjs/toolkit";
import users from "../features/users/usersSlice";
import subscriptions from "../features/subscriptions/subscriptionsSlice";
import payments from "../features/payments/paymentsSlice";
import dashboard from "../features/dashboard/dashboardSlice";

export const store = configureStore({
  reducer: { users, subscriptions, payments, dashboard },
});

export default store;