import { BrowserRouter, Routes, Route, NavLink, Navigate } from "react-router-dom";

import DashboardPage from "./features/dashboard/DashboardPage";
import UsersPage from "./features/users/UsersPage";
import SubscriptionsPage from "./features/subscriptions/SubscriptionsPage";
import PaymentsPage from "./features/payments/PaymentsPage";

function NavBar() {
  const base =
    "px-3 py-2 rounded hover:bg-gray-100 text-gray-700 transition";
  const active = "bg-gray-200 font-medium";

  return (
    <nav className="flex items-center gap-2 p-3 border-b bg-white shadow-sm">
      <NavLink
        to="/dashboard"
        className={({ isActive }) => (isActive ? `${base} ${active}` : base)}
      >
        Dashboard
      </NavLink>

      <NavLink
        to="/users"
        className={({ isActive }) => (isActive ? `${base} ${active}` : base)}
      >
        Users
      </NavLink>

      <NavLink
        to="/subscriptions"
        className={({ isActive }) => (isActive ? `${base} ${active}` : base)}
      >
        Subscriptions
      </NavLink>

      <NavLink
        to="/payments"
        className={({ isActive }) => (isActive ? `${base} ${active}` : base)}
      >
        Payments
      </NavLink>
    </nav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-50 text-gray-900">
        <NavBar />

        <div className="p-6">
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/users" element={<UsersPage />} />
            <Route path="/subscriptions" element={<SubscriptionsPage />} />
            <Route path="/payments" element={<PaymentsPage />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}