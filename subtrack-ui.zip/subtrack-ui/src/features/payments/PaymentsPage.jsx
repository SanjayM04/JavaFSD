import { useEffect, useMemo, useState } from "react";
import api from "../../api/client";
import useFetch from "../../hooks/useFetch";

export default function PaymentsPage() {
  const { data: users } = useFetch(() => api.get("/users"), []);
  const [selectedUserId, setSelectedUserId] = useState("");
  const { data: subs } = useFetch(
    () => selectedUserId ? api.get(`/users/${selectedUserId}/subscriptions`) : Promise.resolve({ data: [] }),
    [selectedUserId]
  );
  const [selectedSubId, setSelectedSubId] = useState("");

  const { data: payments, setData: setPayments, loading: payLoading, error: payError } = useFetch(
    () => selectedSubId ? api.get(`/subscriptions/${selectedSubId}/payments`) : Promise.resolve({ data: [] }),
    [selectedSubId]
  );

  const sortedUsers = useMemo(() => Array.isArray(users) ? [...users].sort((a,b)=>a.name.localeCompare(b.name)) : [], [users]);
  const sortedSubs = useMemo(() => Array.isArray(subs) ? [...subs].sort((a,b)=>a.name.localeCompare(b.name)) : [], [subs]);

  useEffect(() => { if (!selectedUserId && sortedUsers.length) setSelectedUserId(String(sortedUsers[0].id)); }, [sortedUsers, selectedUserId]);
  useEffect(() => { setSelectedSubId(""); }, [selectedUserId]);
  useEffect(() => { if (!selectedSubId && sortedSubs.length) setSelectedSubId(String(sortedSubs[0].id)); }, [sortedSubs, selectedSubId]);

  const [form, setForm] = useState({ amount: "", paidDate: "", method: "", notes: "" });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);

  // Edit modal
  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState({ id: null, amount: "", paidDate: "", method: "", notes: "" });
  const [editErrors, setEditErrors] = useState({});
  const [editSaving, setEditSaving] = useState(false);
  const [editError, setEditError] = useState(null);

  const validate = (data) => {
    const e = {};
    if (data.amount === "" || isNaN(Number(data.amount)) || Number(data.amount) < 0) e.amount = "Amount must be a non-negative number";
    if (!data.paidDate) e.paidDate = "Paid date is required";
    return e;
  };

  const createPayment = async (e) => {
    e.preventDefault();
    if (!selectedSubId) { setSaveError("Select a subscription first"); return; }
    const e1 = validate(form); setErrors(e1);
    if (Object.keys(e1).length) return;

    setSaving(true); setSaveError(null);
    try {
      const payload = {
        amount: Number(form.amount),
        paidDate: form.paidDate,
        method: form.method?.trim() || undefined,
        notes: form.notes?.trim() || undefined
      };
      const res = await api.post(`/subscriptions/${selectedSubId}/payments`, payload);
      setPayments((prev)=>[...prev, res.data]);
      setForm({ amount: "", paidDate: "", method: "", notes: "" });
    } catch (err) {
      const data = err?.response?.data;
      if (data?.errors?.length) setSaveError(data.errors.map(x=>`${x.field}: ${x.message}`).join(", "));
      else setSaveError(data?.message || "Failed to create payment");
    } finally { setSaving(false); }
  };

  const openEdit = (p) => {
    setEditForm({ id: p.id, amount: String(p.amount ?? ""), paidDate: p.paidDate ?? "", method: p.method ?? "", notes: p.notes ?? "" });
    setEditErrors({}); setEditError(null); setEditOpen(true);
  };

  const saveEdit = async (e) => {
    e.preventDefault();
    const e2 = validate(editForm); setEditErrors(e2);
    if (Object.keys(e2).length) return;

    setEditSaving(true); setEditError(null);
    try {
      const payload = {
        amount: editForm.amount === "" ? undefined : Number(editForm.amount),
        paidDate: editForm.paidDate || undefined,
        method: editForm.method?.trim() || undefined,
        notes: editForm.notes?.trim() || undefined
      };
      const res = await api.put(`/payments/${editForm.id}`, payload);
      setPayments((prev)=>prev.map((p)=> (p.id === editForm.id ? res.data : p)));
      setEditOpen(false);
    } catch (err) {
      const data = err?.response?.data;
      if (data?.errors?.length) setEditError(data.errors.map(x=>`${x.field}: ${x.message}`).join(", "));
      else setEditError(data?.message || "Failed to update payment");
    } finally { setEditSaving(false); }
  };

  const del = async (id) => {
    if (!confirm("Delete this payment?")) return;
    try {
      await api.delete(`/payments/${id}`);
      setPayments((prev)=>prev.filter((p)=>p.id !== id));
    } catch { alert("Delete failed"); }
  };

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Payments</h1>

      <div className="bg-white shadow p-6 rounded max-w-4xl flex flex-col sm:flex-row gap-4">
        <label className="text-sm">
          <div className="text-gray-600 mb-1">Select User</div>
          <select value={selectedUserId} onChange={(e)=>setSelectedUserId(e.target.value)} className="border rounded px-3 py-2 min-w-[240px]">
            {sortedUsers.map(u => <option key={u.id} value={u.id}>{u.name} — {u.email}</option>)}
          </select>
        </label>
        <label className="text-sm">
          <div className="text-gray-600 mb-1">Select Subscription</div>
          <select value={selectedSubId} onChange={(e)=>setSelectedSubId(e.target.value)} disabled={!sortedSubs.length} className="border rounded px-3 py-2 min-w-[280px] disabled:bg-gray-100">
            {sortedSubs.map(s => <option key={s.id} value={s.id}>{s.name} — ₹{Number(s.amount).toFixed(2)} ({s.billingCycle})</option>)}
          </select>
        </label>
      </div>

      <form onSubmit={createPayment} className="bg-white shadow p-6 rounded max-w-4xl space-y-4">
        <div className="text-xl font-semibold">Add Payment</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Amount" error={errors.amount}>
            <input className="w-full border rounded px-3 py-2" type="number" step="0.01"
              value={form.amount} onChange={(e)=>setForm({ ...form, amount: e.target.value })}/>
          </Field>
          <Field label="Paid Date" error={errors.paidDate}>
            <input className="w-full border rounded px-3 py-2" type="date"
              value={form.paidDate} onChange={(e)=>setForm({ ...form, paidDate: e.target.value })}/>
          </Field>
          <Field label="Method (optional)">
            <input className="w-full border rounded px-3 py-2"
              value={form.method} onChange={(e)=>setForm({ ...form, method: e.target.value })} placeholder="UPI / Card"/>
          </Field>
          <Field label="Notes (optional)">
            <input className="w-full border rounded px-3 py-2"
              value={form.notes} onChange={(e)=>setForm({ ...form, notes: e.target.value })} placeholder="Auto-renew"/>
          </Field>
        </div>
        {saveError && <div className="text-red-600 text-sm">{saveError}</div>}
        <button disabled={saving || !selectedSubId} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50">
          {saving ? "Saving..." : "Create Payment"}
        </button>
      </form>

      <div className="bg-white shadow rounded overflow-x-auto">
        {selectedSubId && payLoading && <div className="p-4 text-gray-500">Loading payments…</div>}
        {selectedSubId && payError && <div className="p-4 text-red-600">Error: {payError}</div>}
        {selectedSubId && !payLoading && !payError && (
          <table className="min-w-full text-sm">
            <thead className="bg-gray-100 text-gray-700">
              <tr>
                <th className="p-3 text-left">ID</th>
                <th className="p-3 text-left">Amount</th>
                <th className="p-3 text-left">Paid Date</th>
                <th className="p-3 text-left">Method</th>
                <th className="p-3 text-left">Notes</th>
                <th className="p-3 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {(payments ?? []).map((p) => (
                <tr key={p.id} className="border-b last:border-b-0">
                  <td className="p-3">{p.id}</td>
                  <td className="p-3">₹ {Number(p.amount).toFixed(2)}</td>
                  <td className="p-3">{p.paidDate}</td>
                  <td className="p-3">{p.method ?? "-"}</td>
                  <td className="p-3">{p.notes ?? "-"}</td>
                  <td className="p-3 flex gap-2">
                    <button onClick={()=>openEdit(p)} className="px-3 py-1 bg-gray-700 text-white rounded hover:bg-gray-800">Edit</button>
                    <button onClick={()=>del(p.id)} className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700">Delete</button>
                  </td>
                </tr>
              ))}
              {(payments ?? []).length === 0 && (
                <tr><td className="p-3 text-gray-500" colSpan="6">No payments for this subscription.</td></tr>
              )}
            </tbody>
          </table>
        )}
        {!selectedSubId && <div className="p-4 text-gray-500">Select a user and subscription to view payments.</div>}
      </div>

      {editOpen && (
        <Modal title="Edit Payment" onClose={()=>setEditOpen(false)}>
          <form onSubmit={saveEdit} className="space-y-4">
            <Field label="Amount" error={editErrors.amount}>
              <input className="w-full border rounded px-3 py-2" type="number" step="0.01"
                value={editForm.amount} onChange={(e)=>setEditForm({ ...editForm, amount: e.target.value })}/>
            </Field>
            <Field label="Paid Date" error={editErrors.paidDate}>
              <input className="w-full border rounded px-3 py-2" type="date"
                value={editForm.paidDate} onChange={(e)=>setEditForm({ ...editForm, paidDate: e.target.value })}/>
            </Field>
            <Field label="Method">
              <input className="w-full border rounded px-3 py-2"
                value={editForm.method} onChange={(e)=>setEditForm({ ...editForm, method: e.target.value })}/>
            </Field>
            <Field label="Notes">
              <input className="w-full border rounded px-3 py-2"
                value={editForm.notes} onChange={(e)=>setEditForm({ ...editForm, notes: e.target.value })}/>
            </Field>
            {editError && <div className="text-red-600 text-sm">{editError}</div>}
            <div className="flex gap-2">
              <button disabled={editSaving} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50">
                {editSaving ? "Saving..." : "Save Changes"}
              </button>
              <button type="button" onClick={()=>setEditOpen(false)} className="px-4 py-2 border rounded">Cancel</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

function Field({ label, error, children }) {
  return (
    <label className="text-sm w-full block">
      <div className="text-gray-600 mb-1">{label}</div>
      {children}
      {error && <div className="text-red-600 text-xs mt-1">{error}</div>}
    </label>
  );
}

function Modal({ title, children, onClose }) {
  useEffect(() => {
    const onEsc = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onEsc);
    return () => window.removeEventListener("keydown", onEsc);
  }, [onClose]);
  return (
    <div className="fixed inset-0 bg-black/30 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded shadow-lg w-full max-w-2xl">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="text-lg font-semibold">{title}</div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800">✕</button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}