import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../../api/client";

export const fetchPaymentsBySubscription = createAsyncThunk(
  "payments/fetchBySubscription",
  async (subscriptionId) => {
    const res = await api.get(`/subscriptions/${subscriptionId}/payments`);
    return { subscriptionId, data: res.data };
  }
);

export const createPayment = createAsyncThunk(
  "payments/create",
  async ({ subscriptionId, payload }) => {
    const res = await api.post(`/subscriptions/${subscriptionId}/payments`, payload);
    return { subscriptionId, data: res.data };
  }
);

export const updatePayment = createAsyncThunk(
  "payments/update",
  async ({ id, payload }) => {
    const res = await api.put(`/payments/${id}`, payload);
    return res.data;
  }
);

export const deletePayment = createAsyncThunk("payments/delete", async (id) => {
  await api.delete(`/payments/${id}`);
  return id;
});

const slice = createSlice({
  name: "payments",
  initialState: {
    bySub: {},          
    statusBySub: {},      
    errorBySub: {},      
  },
  reducers: {},
  extraReducers: (b) => {
    b.addCase(fetchPaymentsBySubscription.pending, (s, a) => {
      const subId = a.meta.arg;
      s.statusBySub[subId] = "loading";
      s.errorBySub[subId] = null;
    });
    b.addCase(fetchPaymentsBySubscription.fulfilled, (s, a) => {
      const { subscriptionId, data } = a.payload;
      s.statusBySub[subscriptionId] = "succeeded";
      s.bySub[subscriptionId] = data;
    });
    b.addCase(fetchPaymentsBySubscription.rejected, (s, a) => {
      const subId = a.meta.arg;
      s.statusBySub[subId] = "failed";
      s.errorBySub[subId] = a.error.message || "Failed to fetch payments";
    });

    b.addCase(createPayment.fulfilled, (s, a) => {
      const { subscriptionId, data } = a.payload;
      if (!s.bySub[subscriptionId]) s.bySub[subscriptionId] = [];
      s.bySub[subscriptionId].push(data);
    });

    b.addCase(updatePayment.fulfilled, (s, a) => {
      const updated = a.payload;
      for (const subId of Object.keys(s.bySub)) {
        const list = s.bySub[subId];
        const i = list.findIndex((x) => x.id === updated.id);
        if (i !== -1) {
          list[i] = updated;
          break;
        }
      }
    });

    b.addCase(deletePayment.fulfilled, (s, a) => {
      const id = a.payload;
      for (const subId of Object.keys(s.bySub)) {
        s.bySub[subId] = s.bySub[subId]?.filter((x) => x.id !== id) || [];
      }
    });
  },
});

export default slice.reducer;

export const selectPaymentsBySub = (state, subId) => state.payments.bySub[subId] || [];
export const selectPaymentsStatus = (state, subId) => state.payments.statusBySub[subId] || "idle";
export const selectPaymentsError = (state, subId) => state.payments.errorBySub[subId] || null;