import { useMemo, useState } from "react";
import useFetch from "../../hooks/useFetch";
import api from "../../api/client";

export default function DashboardPage() {
  const { data: users } = useFetch(() => api.get("/users"), []);

  const [selectedUserId, setSelectedUserId] = useState("ALL");

  const summaryReq = useMemo(() => {
    const params = new URLSearchParams({ days: "30" });
    if (selectedUserId !== "ALL") params.append("userId", selectedUserId);
    return `/dashboard/summary?${params.toString()}`;
  }, [selectedUserId]);

  const { data, loading, error } = useFetch(() => api.get(summaryReq), [summaryReq]);

  if (loading) {
    return <div className="text-gray-500">Loading dashboard…</div>;
  }

  if (error) {
    return <div className="text-red-600">Error: {error}</div>;
  }

  const { monthlyTotal, yearlyTotal, activeSubscriptions, upcomingRenewals } = data || {};

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <h1 className="text-3xl font-bold">Dashboard</h1>

        <label className="text-sm">
          <div className="text-gray-600 mb-1">Scope</div>
          <select
            value={selectedUserId}
            onChange={(e) => setSelectedUserId(e.target.value)}
            className="border rounded px-3 py-2 min-w-[260px] bg-white"
          >
            <option value="ALL">All Users</option>
            {(users ?? []).map((u) => (
              <option key={u.id} value={u.id}>
                {u.name} — {u.email}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <SummaryCard title="Monthly Total" value={`₹ ${Number(monthlyTotal).toFixed(2)}`} />
        <SummaryCard title="Yearly Total" value={`₹ ${Number(yearlyTotal).toFixed(2)}`} />
        <SummaryCard title="Active Subscriptions" value={activeSubscriptions ?? 0} />
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-4">
          Upcoming Renewals (Next 30 Days){selectedUserId !== "ALL" ? ` — for user #${selectedUserId}` : ""}
        </h2>

        <div className="bg-white shadow rounded overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-100 text-gray-700">
              <tr>
                <th className="text-left p-3">Name</th>
                <th className="text-left p-3">Renewal Date</th>
                <th className="text-left p-3">Days Left</th>
                <th className="text-left p-3">Amount</th>
                <th className="text-left p-3">Cycle</th>
              </tr>
            </thead>
            <tbody>
              {(upcomingRenewals ?? []).map((item) => (
                <tr key={item.subscriptionId} className="border-b last:border-b-0">
                  <td className="p-3">{item.name}</td>
                  <td className="p-3">{item.nextRenewalDate}</td>
                  <td className="p-3">{item.daysLeft}</td>
                  <td className="p-3">₹ {Number(item.amount).toFixed(2)}</td>
                  <td className="p-3">{item.billingCycle}</td>
                </tr>
              ))}

              {(!upcomingRenewals || upcomingRenewals.length === 0) && (
                <tr>
                  <td className="p-3 text-gray-500" colSpan="5">
                    No renewals in the selected window.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function SummaryCard({ title, value }) {
  return (
    <div className="bg-white shadow rounded p-5">
      <div className="text-gray-600 text-sm">{title}</div>
      <div className="text-2xl font-bold mt-1">{value}</div>
    </div>
  );
}