import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../../api/client";

export const fetchDashboardSummary = createAsyncThunk(
  "dashboard/fetchSummary",
  async ({ userId = "ALL", days = 30 }) => {
    const params = new URLSearchParams({ days: String(days) });
    if (userId !== "ALL") params.append("userId", userId);
    const res = await api.get(`/dashboard/summary?${params.toString()}`);
    return { key: String(userId), data: res.data };
  }
);

const slice = createSlice({
  name: "dashboard",
  initialState: {
    byKey: {},      
    status: "idle",
    error: null,
    selectedUserId: "ALL",
    days: 30,
  },
  reducers: {
    setDashboardScope: (s, a) => {
      if (a.payload?.userId !== undefined) s.selectedUserId = a.payload.userId;
      if (a.payload?.days !== undefined) s.days = a.payload.days;
    },
  },
  extraReducers: (b) => {
    b.addCase(fetchDashboardSummary.pending, (s) => {
      s.status = "loading";
      s.error = null;
    });
    b.addCase(fetchDashboardSummary.fulfilled, (s, a) => {
      s.status = "succeeded";
      s.byKey[a.payload.key] = a.payload.data;
    });
    b.addCase(fetchDashboardSummary.rejected, (s, a) => {
      s.status = "failed";
      s.error = a.error.message || "Failed to load dashboard";
    });
  },
});

export const { setDashboardScope } = slice.actions;
export default slice.reducer;

export const selectDashboardScope = (state) => ({
  userId: state.dashboard.selectedUserId,
  days: state.dashboard.days,
});
export const selectDashboardStatus = (state) => state.dashboard.status;
export const selectDashboardError = (state) => state.dashboard.error;
export const selectDashboardSummary = (state, userId = "ALL") =>
  state.dashboard.byKey[String(userId)] || null;