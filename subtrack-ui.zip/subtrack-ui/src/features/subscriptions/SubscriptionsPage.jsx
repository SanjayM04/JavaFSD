import { useEffect, useMemo, useState } from "react";
import api from "../../api/client";
import useFetch from "../../hooks/useFetch";

const BILLING_CYCLES = ["MONTHLY", "YEARLY"];
const STATUSES = ["ACTIVE", "INACTIVE", "CANCELLED"];

export default function SubscriptionsPage() {
  const { data: users } = useFetch(() => api.get("/users"), []);
  const [selectedUserId, setSelectedUserId] = useState("");

  const { data: subs, setData: setSubs, loading: subsLoading, error: subsError } = useFetch(
    () => selectedUserId ? api.get(`/users/${selectedUserId}/subscriptions`) : Promise.resolve({ data: [] }),
    [selectedUserId]
  );

  const [form, setForm] = useState({ name: "", amount: "", billingCycle: "MONTHLY", startDate: "", status: "ACTIVE" });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);

  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState({ id: null, name: "", amount: "", billingCycle: "MONTHLY", startDate: "", status: "ACTIVE", nextRenewalDate: "" });
  const [editErrors, setEditErrors] = useState({});
  const [editSaving, setEditSaving] = useState(false);
  const [editError, setEditError] = useState(null);

  const sortedUsers = useMemo(() => Array.isArray(users) ? [...users].sort((a,b)=>a.name.localeCompare(b.name)) : [], [users]);
  useEffect(() => { if (!selectedUserId && sortedUsers.length) setSelectedUserId(String(sortedUsers[0].id)); }, [sortedUsers, selectedUserId]);

  const validate = (data) => {
    const e = {};
    if (!data.name?.trim()) e.name = "Name is required";
    if (data.amount === "" || isNaN(Number(data.amount)) || Number(data.amount) < 0) e.amount = "Amount must be a non-negative number";
    if (!BILLING_CYCLES.includes(data.billingCycle)) e.billingCycle = "Billing cycle is required";
    if (!STATUSES.includes(data.status)) e.status = "Status is required";
    if (data.startDate && !/^\d{4}-\d{2}-\d{2}$/.test(data.startDate)) e.startDate = "Start date must be YYYY-MM-DD";
    if (data.nextRenewalDate && !/^\d{4}-\d{2}-\d{2}$/.test(data.nextRenewalDate)) e.nextRenewalDate = "Next renewal must be YYYY-MM-DD";
    return e;
  };

  const createSub = async (e) => {
    e.preventDefault();
    const e1 = validate(form); setErrors(e1);
    if (Object.keys(e1).length) return;
    setSaving(true); setSaveError(null);
    try {
      const payload = {
        name: form.name.trim(),
        amount: Number(form.amount),
        billingCycle: form.billingCycle,
        status: form.status,
        ...(form.startDate ? { startDate: form.startDate } : {})
      };
      const res = await api.post(`/users/${selectedUserId}/subscriptions`, payload);
      setSubs((prev) => [...prev, res.data]);
      setForm({ name: "", amount: "", billingCycle: "MONTHLY", startDate: "", status: "ACTIVE" });
    } catch (err) {
      const data = err?.response?.data;
      if (data?.errors?.length) setSaveError(data.errors.map(x=>`${x.field}: ${x.message}`).join(", "));
      else setSaveError(data?.message || "Failed to create subscription");
    } finally { setSaving(false); }
  };

  const openEdit = (s) => {
    setEditForm({
      id: s.id,
      name: s.name,
      amount: String(s.amount ?? ""),
      billingCycle: s.billingCycle,
      startDate: s.startDate ?? "",
      status: s.status,
      nextRenewalDate: s.nextRenewalDate ?? ""
    });
    setEditErrors({}); setEditError(null); setEditOpen(true);
  };

  const saveEdit = async (e) => {
    e.preventDefault();
    const e2 = validate(editForm); setEditErrors(e2);
    if (Object.keys(e2).length) return;

    setEditSaving(true); setEditError(null);
    try {
      const payload = {
        name: editForm.name.trim(),
        amount: editForm.amount === "" ? undefined : Number(editForm.amount),
        billingCycle: editForm.billingCycle,
        status: editForm.status,
        startDate: editForm.startDate || undefined,
        nextRenewalDate: editForm.nextRenewalDate || undefined
      };
      const res = await api.put(`/subscriptions/${editForm.id}`, payload);
      setSubs((prev) => prev.map((s) => (s.id === editForm.id ? res.data : s)));
      setEditOpen(false);
    } catch (err) {
      const data = err?.response?.data;
      if (data?.errors?.length) setEditError(data.errors.map(x=>`${x.field}: ${x.message}`).join(", "));
      else setEditError(data?.message || "Failed to update subscription");
    } finally { setEditSaving(false); }
  };

  const del = async (id) => {
    if (!confirm("Delete this subscription?")) return;
    try {
      await api.delete(`/subscriptions/${id}`);
      setSubs((prev) => prev.filter((s) => s.id !== id));
    } catch { alert("Delete failed"); }
  };

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Subscriptions</h1>

      <div className="bg-white shadow p-6 rounded max-w-3xl flex items-center gap-4">
        <label className="text-sm">
          <div className="text-gray-600 mb-1">Select User</div>
          <select
            value={selectedUserId}
            onChange={(e)=>setSelectedUserId(e.target.value)}
            className="border rounded px-3 py-2 min-w-[240px]"
          >
            {sortedUsers.map(u => <option key={u.id} value={u.id}>{u.name} — {u.email}</option>)}
          </select>
        </label>
      </div>

      <form onSubmit={createSub} className="bg-white shadow p-6 rounded max-w-3xl space-y-4">
        <div className="text-xl font-semibold">Add Subscription</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Name" error={errors.name}>
            <input className="w-full border rounded px-3 py-2"
              value={form.name} onChange={(e)=>setForm({ ...form, name: e.target.value })}
              placeholder="Netflix" />
          </Field>
          <Field label="Amount" error={errors.amount}>
            <input className="w-full border rounded px-3 py-2" type="number" step="0.01"
              value={form.amount} onChange={(e)=>setForm({ ...form, amount: e.target.value })}
              placeholder="499" />
          </Field>
          <Field label="Billing Cycle" error={errors.billingCycle}>
            <select className="w-full border rounded px-3 py-2"
              value={form.billingCycle} onChange={(e)=>setForm({ ...form, billingCycle: e.target.value })}>
              {BILLING_CYCLES.map(x => <option key={x} value={x}>{x}</option>)}
            </select>
          </Field>
          <Field label="Start Date (optional)" error={errors.startDate}>
            <input className="w-full border rounded px-3 py-2" type="date"
              value={form.startDate} onChange={(e)=>setForm({ ...form, startDate: e.target.value })}/>
          </Field>
          <Field label="Status" error={errors.status}>
            <select className="w-full border rounded px-3 py-2"
              value={form.status} onChange={(e)=>setForm({ ...form, status: e.target.value })}>
              {STATUSES.map(x => <option key={x} value={x}>{x}</option>)}
            </select>
          </Field>
        </div>
        {saveError && <div className="text-red-600 text-sm">{saveError}</div>}
        <button disabled={saving} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50">
          {saving ? "Saving..." : "Create Subscription"}
        </button>
      </form>

      <div className="bg-white shadow rounded overflow-x-auto">
        {subsLoading && <div className="p-4 text-gray-500">Loading subscriptions…</div>}
        {subsError && <div className="p-4 text-red-600">Error: {subsError}</div>}
        {!subsLoading && !subsError && (
          <table className="min-w-full text-sm">
            <thead className="bg-gray-100 text-gray-700">
              <tr>
                <th className="p-3 text-left">ID</th>
                <th className="p-3 text-left">Name</th>
                <th className="p-3 text-left">Amount</th>
                <th className="p-3 text-left">Cycle</th>
                <th className="p-3 text-left">Start</th>
                <th className="p-3 text-left">Next Renewal</th>
                <th className="p-3 text-left">Status</th>
                <th className="p-3 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {(subs ?? []).map((s) => (
                <tr key={s.id} className="border-b last:border-b-0">
                  <td className="p-3">{s.id}</td>
                  <td className="p-3">{s.name}</td>
                  <td className="p-3">₹ {Number(s.amount).toFixed(2)}</td>
                  <td className="p-3">{s.billingCycle}</td>
                  <td className="p-3">{s.startDate ?? "-"}</td>
                  <td className="p-3">{s.nextRenewalDate ?? "-"}</td>
                  <td className="p-3">{s.status}</td>
                  <td className="p-3 flex gap-2">
                    <button onClick={() => openEdit(s)} className="px-3 py-1 bg-gray-700 text-white rounded hover:bg-gray-800">Edit</button>
                    <button onClick={() => del(s.id)} className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700">Delete</button>
                  </td>
                </tr>
              ))}
              {(subs ?? []).length === 0 && (
                <tr><td className="p-3 text-gray-500" colSpan="8">No subscriptions for this user.</td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>

      {editOpen && (
        <Modal title="Edit Subscription" onClose={()=>setEditOpen(false)}>
          <form onSubmit={saveEdit} className="space-y-4">
            <Field label="Name" error={editErrors.name}>
              <input className="w-full border rounded px-3 py-2"
                value={editForm.name} onChange={(e)=>setEditForm({ ...editForm, name: e.target.value })}/>
            </Field>
            <Field label="Amount" error={editErrors.amount}>
              <input className="w-full border rounded px-3 py-2" type="number" step="0.01"
                value={editForm.amount} onChange={(e)=>setEditForm({ ...editForm, amount: e.target.value })}/>
            </Field>
            <Field label="Billing Cycle" error={editErrors.billingCycle}>
              <select className="w-full border rounded px-3 py-2"
                value={editForm.billingCycle} onChange={(e)=>setEditForm({ ...editForm, billingCycle: e.target.value })}>
                {BILLING_CYCLES.map(x => <option key={x} value={x}>{x}</option>)}
              </select>
            </Field>
            <Field label="Start Date" error={editErrors.startDate}>
              <input className="w-full border rounded px-3 py-2" type="date"
                value={editForm.startDate} onChange={(e)=>setEditForm({ ...editForm, startDate: e.target.value })}/>
            </Field>
            <Field label="Next Renewal" error={editErrors.nextRenewalDate}>
              <input className="w-full border rounded px-3 py-2" type="date"
                value={editForm.nextRenewalDate} onChange={(e)=>setEditForm({ ...editForm, nextRenewalDate: e.target.value })}/>
            </Field>
            <Field label="Status" error={editErrors.status}>
              <select className="w-full border rounded px-3 py-2"
                value={editForm.status} onChange={(e)=>setEditForm({ ...editForm, status: e.target.value })}>
                {STATUSES.map(x => <option key={x} value={x}>{x}</option>)}
              </select>
            </Field>

            {editError && <div className="text-red-600 text-sm">{editError}</div>}

            <div className="flex gap-2">
              <button disabled={editSaving} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50">
                {editSaving ? "Saving..." : "Save Changes"}
              </button>
              <button type="button" onClick={()=>setEditOpen(false)} className="px-4 py-2 border rounded">Cancel</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

function Field({ label, error, children }) {
  return (
    <label className="text-sm w-full block">
      <div className="text-gray-600 mb-1">{label}</div>
      {children}
      {error && <div className="text-red-600 text-xs mt-1">{error}</div>}
    </label>
  );
}

function Modal({ title, children, onClose }) {
  useEffect(() => {
    const onEsc = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onEsc);
    return () => window.removeEventListener("keydown", onEsc);
  }, [onClose]);
  return (
    <div className="fixed inset-0 bg-black/30 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded shadow-lg w-full max-w-2xl">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="text-lg font-semibold">{title}</div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800">✕</button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}
