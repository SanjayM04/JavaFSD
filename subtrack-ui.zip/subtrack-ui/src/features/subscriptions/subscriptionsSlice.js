import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../../api/client";

export const fetchSubscriptionsByUser = createAsyncThunk(
  "subscriptions/fetchByUser",
  async (userId) => {
    const res = await api.get(`/users/${userId}/subscriptions`);
    return { userId, data: res.data };
  }
);

export const createSubscription = createAsyncThunk(
  "subscriptions/create",
  async ({ userId, payload }) => {
    const res = await api.post(`/users/${userId}/subscriptions`, payload);
    return { userId, data: res.data };
  }
);

export const updateSubscription = createAsyncThunk(
  "subscriptions/update",
  async ({ id, payload }) => {
    const res = await api.put(`/subscriptions/${id}`, payload);
    return res.data;
  }
);

export const deleteSubscription = createAsyncThunk(
  "subscriptions/delete",
  async (id) => {
    await api.delete(`/subscriptions/${id}`);
    return id;
  }
);

const slice = createSlice({
  name: "subscriptions",
  initialState: {
    byUser: {},         
    statusByUser: {},     
    errorByUser: {},      
  },
  reducers: {},
  extraReducers: (b) => {
    b.addCase(fetchSubscriptionsByUser.pending, (s, a) => {
      const userId = a.meta.arg;
      s.statusByUser[userId] = "loading";
      s.errorByUser[userId] = null;
    });
    b.addCase(fetchSubscriptionsByUser.fulfilled, (s, a) => {
      const { userId, data } = a.payload;
      s.statusByUser[userId] = "succeeded";
      s.byUser[userId] = data;
    });
    b.addCase(fetchSubscriptionsByUser.rejected, (s, a) => {
      const userId = a.meta.arg;
      s.statusByUser[userId] = "failed";
      s.errorByUser[userId] = a.error.message || "Failed to fetch subscriptions";
    });

    b.addCase(createSubscription.fulfilled, (s, a) => {
      const { userId, data } = a.payload;
      if (!s.byUser[userId]) s.byUser[userId] = [];
      s.byUser[userId].push(data);
    });

    b.addCase(updateSubscription.fulfilled, (s, a) => {
      const updated = a.payload;
      for (const userId of Object.keys(s.byUser)) {
        const list = s.byUser[userId];
        const i = list.findIndex((x) => x.id === updated.id);
        if (i !== -1) {
          list[i] = updated;
          break;
        }
      }
    });

    b.addCase(deleteSubscription.fulfilled, (s, a) => {
      const id = a.payload;
      for (const userId of Object.keys(s.byUser)) {
        s.byUser[userId] = s.byUser[userId]?.filter((x) => x.id !== id) || [];
      }
    });
  },
});

export default slice.reducer;

export const selectSubsByUser = (state, userId) => state.subscriptions.byUser[userId] || [];
export const selectSubsStatus = (state, userId) => state.subscriptions.statusByUser[userId] || "idle";
export const selectSubsError = (state, userId) => state.subscriptions.errorByUser[userId] || null;