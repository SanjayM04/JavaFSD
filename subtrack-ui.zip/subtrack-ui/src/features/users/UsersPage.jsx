import { useEffect, useMemo, useState } from "react";
import api from "../../api/client";
import useFetch from "../../hooks/useFetch";

export default function UsersPage() {
  const { data: users, loading, error, setData: setUsers } = useFetch(() => api.get("/users"), []);

  const [form, setForm] = useState({ name: "", email: "" });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);

  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState({ id: null, name: "", email: "" });
  const [editErrors, setEditErrors] = useState({});
  const [editSaving, setEditSaving] = useState(false);
  const [editError, setEditError] = useState(null);

  const validateUser = (data) => {
    const e = {};
    if (!data.name?.trim()) e.name = "Name is required";
    if (!data.email?.trim()) e.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) e.email = "Email is invalid";
    return e;
  };

  const onCreate = async (e) => {
    e.preventDefault();
    const e1 = validateUser(form);
    setErrors(e1);
    if (Object.keys(e1).length) return;

    setSaving(true); setSaveError(null);
    try {
      const res = await api.post("/users", form);
      setUsers((prev) => [...prev, res.data]);
      setForm({ name: "", email: "" });
    } catch (err) {
      const data = err?.response?.data;
      if (data?.errors?.length) {
        setSaveError(data.errors.map((x) => `${x.field}: ${x.message}`).join(", "));
      } else {
        setSaveError(data?.message || "Failed to create user");
      }
    } finally { setSaving(false); }
  };

  const onDelete = async (id) => {
    if (!confirm("Delete this user?")) return;
    try {
      await api.delete(`/users/${id}`);
      setUsers((prev) => prev.filter((u) => u.id !== id));
    } catch {
      alert("Delete failed");
    }
  };

  const openEdit = (u) => {
    setEditForm({ id: u.id, name: u.name, email: u.email });
    setEditErrors({}); setEditError(null); setEditOpen(true);
  };

  const onEditSave = async (e) => {
    e.preventDefault();
    const e2 = validateUser(editForm);
    setEditErrors(e2);
    if (Object.keys(e2).length) return;

    setEditSaving(true); setEditError(null);
    try {
      const res = await api.put(`/users/${editForm.id}`, { name: editForm.name, email: editForm.email });
      setUsers((prev) => prev.map((u) => (u.id === editForm.id ? res.data : u)));
      setEditOpen(false);
    } catch (err) {
      const data = err?.response?.data;
      if (data?.errors?.length) {
        setEditError(data.errors.map((x) => `${x.field}: ${x.message}`).join(", "));
      } else {
        setEditError(data?.message || "Failed to update user");
      }
    } finally { setEditSaving(false); }
  };

  if (loading) return <div className="text-gray-500">Loading users…</div>;
  if (error)   return <div className="text-red-600">Error: {error}</div>;

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Users</h1>

      <form onSubmit={onCreate} className="bg-white shadow p-6 rounded max-w-lg space-y-4">
        <div className="text-xl font-semibold">Add User</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Name" error={errors.name}>
            <input
              className="w-full border rounded px-3 py-2"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Sanjay"
            />
          </Field>
          <Field label="Email" error={errors.email}>
            <input
              className="w-full border rounded px-3 py-2"
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="sanjay@example.com"
            />
          </Field>
        </div>
        {saveError && <div className="text-red-600 text-sm">{saveError}</div>}
        <button
          disabled={saving}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {saving ? "Saving..." : "Create User"}
        </button>
      </form>

      <div className="bg-white shadow rounded overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-100 text-gray-700">
            <tr>
              <th className="p-3 text-left">ID</th>
              <th className="p-3 text-left">Name</th>
              <th className="p-3 text-left">Email</th>
              <th className="p-3 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {(users ?? []).map((u) => (
              <tr key={u.id} className="border-b last:border-b-0">
                <td className="p-3">{u.id}</td>
                <td className="p-3">{u.name}</td>
                <td className="p-3">{u.email}</td>
                <td className="p-3 flex gap-2">
                  <button onClick={() => openEdit(u)} className="px-3 py-1 bg-gray-700 text-white rounded hover:bg-gray-800">
                    Edit
                  </button>
                  <button onClick={() => onDelete(u.id)} className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {(users ?? []).length === 0 && (
              <tr><td className="p-3 text-gray-500" colSpan="4">No users yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {editOpen && (
        <Modal title="Edit User" onClose={() => setEditOpen(false)}>
          <form onSubmit={onEditSave} className="space-y-4">
            <Field label="Name" error={editErrors.name}>
              <input
                className="w-full border rounded px-3 py-2"
                value={editForm.name}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
              />
            </Field>
            <Field label="Email" error={editErrors.email}>
              <input
                className="w-full border rounded px-3 py-2"
                type="email"
                value={editForm.email}
                onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
              />
            </Field>
            {editError && <div className="text-red-600 text-sm">{editError}</div>}
            <div className="flex gap-2">
              <button disabled={editSaving} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50">
                {editSaving ? "Saving..." : "Save Changes"}
              </button>
              <button type="button" onClick={() => setEditOpen(false)} className="px-4 py-2 border rounded">
                Cancel
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

function Field({ label, error, children }) {
  return (
    <label className="text-sm w-full block">
      <div className="text-gray-600 mb-1">{label}</div>
      {children}
      {error && <div className="text-red-600 text-xs mt-1">{error}</div>}
    </label>
  );
}

function Modal({ title, children, onClose }) {
  useEffect(() => {
    const onEsc = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onEsc);
    return () => window.removeEventListener("keydown", onEsc);
  }, [onClose]);

  return (
    <div className="fixed inset-0 bg-black/30 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded shadow-lg w-full max-w-lg">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="text-lg font-semibold">{title}</div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800">✕</button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}