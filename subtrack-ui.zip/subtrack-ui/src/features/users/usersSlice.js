import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../../api/client";

export const fetchUsers = createAsyncThunk("users/fetchAll", async () => {
  const res = await api.get("/users");
  return res.data;
});

export const createUser = createAsyncThunk("users/create", async (payload) => {
  const res = await api.post("/users", payload);
  return res.data;
});

export const updateUser = createAsyncThunk(
  "users/update",
  async ({ id, payload }) => {
    const res = await api.put(`/users/${id}`, payload);
    return res.data;
  }
);

export const deleteUser = createAsyncThunk("users/delete", async (id) => {
  await api.delete(`/users/${id}`);
  return id;
});

const slice = createSlice({
  name: "users",
  initialState: { list: [], status: "idle", error: null },
  reducers: {},
  extraReducers: (b) => {
    b.addCase(fetchUsers.pending, (s) => {
      s.status = "loading";
      s.error = null;
    });
    b.addCase(fetchUsers.fulfilled, (s, a) => {
      s.status = "succeeded";
      s.list = a.payload;
    });
    b.addCase(fetchUsers.rejected, (s, a) => {
      s.status = "failed";
      s.error = a.error.message || "Failed to fetch users";
    });

    b.addCase(createUser.fulfilled, (s, a) => {
      s.list.push(a.payload);
    });

    b.addCase(updateUser.fulfilled, (s, a) => {
      const i = s.list.findIndex((u) => u.id === a.payload.id);
      if (i !== -1) s.list[i] = a.payload;
    });

    b.addCase(deleteUser.fulfilled, (s, a) => {
      s.list = s.list.filter((u) => u.id !== a.payload);
    });
  },
});

export default slice.reducer;

export const selectUsers = (state) => state.users.list;
export const selectUsersStatus = (state) => state.users.status;
export const selectUsersError = (state) => state.users.error;